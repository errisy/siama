export { SpyLocation } from './testing/location_mock';
export { MockLocationStrategy } from './testing/mock_location_strategy';
