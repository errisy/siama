export declare function assertArrayOfStrings(identifier: string, value: any): void;
