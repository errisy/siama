import { LifecycleHooks } from '../core_private';
export declare function hasLifecycleHook(hook: LifecycleHooks, token: any): boolean;
