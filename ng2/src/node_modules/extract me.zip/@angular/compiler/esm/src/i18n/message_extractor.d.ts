import { Parser } from '../expression_parser/parser';
import { HtmlParser } from '../html_parser';
import { ParseError } from '../parse_util';
import { Message } from './message';
/**
 * All messages extracted from a template.
 */
export declare class ExtractionResult {
    messages: Message[];
    errors: ParseError[];
    constructor(messages: Message[], errors: ParseError[]);
}
/**
 * Removes duplicate messages.
 */
export declare function removeDuplicates(messages: Message[]): Message[];
/**
 * Extracts all messages from a template.
 *
 * Algorithm:
 *
 * To understand the algorithm, you need to know how partitioning works.
 * Partitioning is required as we can use two i18n comments to group node siblings together.
 * That is why we cannot just use nodes.
 *
 * Partitioning transforms an array of HtmlAst into an array of Part.
 * A part can optionally contain a root element or a root text node. And it can also contain
 * children.
 * A part can contain i18n property, in which case it needs to be extracted.
 *
 * Example:
 *
 * The following array of nodes will be split into four parts:
 *
 * ```
 * <a>A</a>
 * <b i18n>B</b>
 * <!-- i18n -->
 * <c>C</c>
 * D
 * <!-- /i18n -->
 * E
 * ```
 *
 * Part 1 containing the a tag. It should not be translated.
 * Part 2 containing the b tag. It should be translated.
 * Part 3 containing the c tag and the D text node. It should be translated.
 * Part 4 containing the E text node. It should not be translated..
 *
 * It is also important to understand how we stringify nodes to create a message.
 *
 * We walk the tree and replace every element node with a placeholder. We also replace
 * all expressions in interpolation with placeholders. We also insert a placeholder element
 * to wrap a text node containing interpolation.
 *
 * Example:
 *
 * The following tree:
 *
 * ```
 * <a>A{{I}}</a><b>B</b>
 * ```
 *
 * will be stringified into:
 * ```
 * <ph name="e0"><ph name="t1">A<ph name="0"/></ph></ph><ph name="e2">B</ph>
 * ```
 *
 * This is what the algorithm does:
 *
 * 1. Use the provided html parser to get the html AST of the template.
 * 2. Partition the root nodes, and process each part separately.
 * 3. If a part does not have the i18n attribute, recurse to process children and attributes.
 * 4. If a part has the i18n attribute, stringify the nodes to create a Message.
 */
export declare class MessageExtractor {
    private _htmlParser;
    private _parser;
    private _implicitTags;
    private _implicitAttrs;
    private _messages;
    private _errors;
    constructor(_htmlParser: HtmlParser, _parser: Parser, _implicitTags: string[], _implicitAttrs: {
        [k: string]: string[];
    });
    extract(template: string, sourceUrl: string): ExtractionResult;
    private _extractMessagesFromPart(part);
    private _recurse(nodes);
    private _recurseToExtractMessagesFromAttributes(nodes);
    private _extractMessagesFromAttributes(p);
}
